package Object;

public class fragment_information_option_setup {
    private String option_setup;

    public fragment_information_option_setup(String option_setup) {
        this.option_setup = option_setup;
    }

    public String getOption_setup() {
        return option_setup;
    }

    public void setOption_setup(String option_setup) {
        this.option_setup = option_setup;
    }
}
