package Object;

public class Option_sort_price {
    private String text_option_sort_price;

    public Option_sort_price(String text_option_sort_price) {
        this.text_option_sort_price = text_option_sort_price;
    }

    public String getText_option_sort_price() {
        return text_option_sort_price;
    }

    public void setText_option_sort_price(String text_option_sort_price) {
        this.text_option_sort_price = text_option_sort_price;
    }
}
