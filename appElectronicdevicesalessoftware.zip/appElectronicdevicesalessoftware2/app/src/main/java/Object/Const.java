package Object;

public class Const {
    public  static final String Key_UserName="UserName";
    public static final  String Key_Password="Password";
    public static final String Key_Uid="Uid";
    public static final String Key_Img_Avatar="Img_Avatar";
    public static final String Key_FullName="FullName";
    public static final String Key_Date_Of_Birth="DateOfBirth";
    public static final String Key_Telephone_Number="PhoneNumber";
    public static final String Key_Address="Address";
    public static final String Key_Id="Id";
    public static final String Key_BaseUrl="http://192.168.1.52";
    public static final String Key_TextHistory="TextSearch";
    public static  final String Key_ImgProduct="Img_product";
    public static final String Key_Name_Product="Name_product";
    public static final String Key_Price_Product="Price_Product";
    public static final String Key_Money_User="Money";
    public static final String Key_Delivery="Delivery";
    public static final String Key_UrlPathAvatar="http://192.168.1.52/information/avatar/";
}
