package Fragment;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.appelectronicdevicesalessoftware.ActivityProductDetail;
import com.example.appelectronicdevicesalessoftware.R;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import Adapter.Adapter_List_Product_Horizontal;
import Adapter.Adapter_product_home;
import Object.Product;
import Retrofit.ApiBanHang;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import Object.Product_Model;


public class Fragment_Product_Detail extends Fragment {
private View view;
private ActivityProductDetail mainActivityProductDetail;
private ImageView imgProduct;
private List<Product> productList;
private Adapter_List_Product_Horizontal adapter_list_product_horizontal;
private List<Product_Model> product_modelList;
private Adapter_product_home adapter_product_home;
private TextView tv_name_product,tv_Price_product,tv_Discount,tv_Cost_product;
private RecyclerView rcv_list_product_same_price,rcv_list_product_same_company;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

       view=inflater.inflate(R.layout.fragment__product__detail, container, false);
       Mapping();
       Initialization();
       GetDataFromActivityDeferent();
       GetDataApi();

       return view;
    }
    private void Mapping()
    {
        rcv_list_product_same_company=view.findViewById(R.id.rcv_list_product_same_company);
        rcv_list_product_same_price=view.findViewById(R.id.rcv_list_product_same_price);
        tv_Cost_product=view.findViewById(R.id.tv_Cost_product);
        tv_name_product=view.findViewById(R.id.tv_name_product_detail);
        tv_Price_product=view.findViewById(R.id.tv_Price_product_detail);
        tv_Discount=view.findViewById(R.id.tv_Discount);
        imgProduct=view.findViewById(R.id.img_product_detail);

    }
    private void Initialization()
    {
        mainActivityProductDetail=(ActivityProductDetail) getActivity();

        product_modelList=new ArrayList<>();
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(mainActivityProductDetail);
        rcv_list_product_same_price.setLayoutManager(linearLayoutManager);
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(mainActivityProductDetail,DividerItemDecoration.VERTICAL);
        rcv_list_product_same_price.addItemDecoration(dividerItemDecoration);
        DividerItemDecoration dividerItemDecoration2=new DividerItemDecoration(mainActivityProductDetail,DividerItemDecoration.HORIZONTAL);
        rcv_list_product_same_price.addItemDecoration(dividerItemDecoration2);
        adapter_list_product_horizontal=new Adapter_List_Product_Horizontal(mainActivityProductDetail);
        rcv_list_product_same_price.setAdapter(adapter_list_product_horizontal);
        adapter_list_product_horizontal.SetUid(mainActivityProductDetail.getUid());
        adapter_list_product_horizontal.setPrice_Product(mainActivityProductDetail.getPrice_Product());

        productList=new ArrayList<>();
        adapter_product_home=new Adapter_product_home(mainActivityProductDetail, new Adapter_product_home.ItemClickProduct() {
            @Override
            public void ItemClickproduct(Product product) {
                Intent intent=new Intent(mainActivityProductDetail, ActivityProductDetail.class);
                intent.putExtra("Product",product);
                intent.putExtra("Uid",mainActivityProductDetail.getUid());
                startActivity(intent);
            }
        });
        GridLayoutManager gridLayoutManager=new GridLayoutManager(mainActivityProductDetail,2);
        rcv_list_product_same_company.setLayoutManager(gridLayoutManager);
        DividerItemDecoration dividerItemDecoration1=new DividerItemDecoration(mainActivityProductDetail,DividerItemDecoration.VERTICAL);
        rcv_list_product_same_company.addItemDecoration(dividerItemDecoration1);
        DividerItemDecoration dividerItemDecoration3=new DividerItemDecoration(mainActivityProductDetail,DividerItemDecoration.HORIZONTAL);
        rcv_list_product_same_company.addItemDecoration(dividerItemDecoration3);
        rcv_list_product_same_company.setAdapter(adapter_product_home);
    }
    private void GetDataFromActivityDeferent()
    {
        String pattern="###,###,###";
        DecimalFormat decimalFormat=new DecimalFormat(pattern);
        float s=0,p=0;
        s=mainActivityProductDetail.getDiscount() * (mainActivityProductDetail.getPrice_Product()/100);
        p=mainActivityProductDetail.getPrice_Product()-s;
        Glide.with(mainActivityProductDetail).load(mainActivityProductDetail.getImg_Product()).into(imgProduct);
        tv_name_product.setText(mainActivityProductDetail.getName_Product());
        tv_Cost_product.setText(String.valueOf(decimalFormat.format(mainActivityProductDetail.getPrice_Product())));
        tv_Cost_product.setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
        tv_Discount.setText(String.valueOf(mainActivityProductDetail.getDiscount()));
        tv_Price_product.setText(String.valueOf(decimalFormat.format(p)));


    }
    private void GetDataApi()
    {
        ApiBanHang.apiHang.getListProduct().enqueue(new Callback<Product_Model>() {
            @Override
            public void onResponse(Call<Product_Model> call, Response<Product_Model> response) {
                List<Product> list=new ArrayList<>();
                Product_Model product_model=response.body();
                product_modelList.add(product_model);
                adapter_list_product_horizontal.setdata(product_modelList);
                list=response.body().getResult();
                for(Product product:list)
                {
                    if(product.getPrice_Product()< mainActivityProductDetail.getPrice_Product())
                    {
                        productList.add(product);
                        adapter_product_home.setdata(productList);
                    }
                }

                }


            @Override
            public void onFailure(Call<Product_Model> call, Throwable t) {

            }
        });
    }
}