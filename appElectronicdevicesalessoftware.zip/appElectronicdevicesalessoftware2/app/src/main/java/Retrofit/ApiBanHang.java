package Retrofit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Object.Product_Model;

import io.reactivex.rxjava3.core.Observable;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import Object.Const;

public interface ApiBanHang {
    Gson gson=new GsonBuilder().setDateFormat("dd-MM-yy").create();

    ApiBanHang apiHang=new Retrofit.Builder()
            .baseUrl(Const.Key_BaseUrl + "/banhang/")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(ApiBanHang.class);

    @GET("getdata.php")
    Call<Product_Model> getListProduct();
}
