package com.example.appelectronicdevicesalessoftware;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import Adapter.Adapter_History_Search_Of_User;
import Object.HistorySearch;
import Retrofit.ApiHistorySearch;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivityHistorySearch extends AppCompatActivity {
private RecyclerView rcv_List_text_searched;
private Adapter_History_Search_Of_User adapter_history_search_of_user;
private List<HistorySearch> historysearchlist,HistorySearchList;
private EditText edt_Search;
private ImageButton btn_search2,btn_Back_History_Search_Of_User;
private String TextSearch;
private String TextSearched;
private int Uid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_search);
        Mapping();
        Initialization();
        GetDataIntent();
        //GetTextSearchedApi();
        SetOnClick();


    }
    private void Mapping()
    {
        btn_Back_History_Search_Of_User=findViewById(R.id.btn_back_history_search);
        edt_Search=findViewById(R.id.edt_search);
        btn_search2=findViewById(R.id.btn_Search2);
        rcv_List_text_searched=findViewById(R.id.rcv_list_history_search);
    }
    private void Initialization()
    {
        historysearchlist=new ArrayList<>();
        HistorySearchList=new ArrayList<>();
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        rcv_List_text_searched.setLayoutManager(linearLayoutManager);
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        rcv_List_text_searched.addItemDecoration(dividerItemDecoration);
        adapter_history_search_of_user=new Adapter_History_Search_Of_User(this, new Adapter_History_Search_Of_User.ItemClick() {
            @Override
            public void ClickText(HistorySearch historySearch) {
                edt_Search.setText(historySearch.getTextSearch());
            }

            @Override
            public void ClickDeleteTextSearched(HistorySearch historySearch) {
                NotificationConfirmDeleteTextSearched(historySearch.getTextSearch());
            }
        });

                rcv_List_text_searched.setAdapter(adapter_history_search_of_user);

    }
    private void GetDataIntent()
    {
        int Uid=getIntent().getIntExtra("Uid",1);
        setUid(Uid);

    }
    private void GetDataUi()
    {
        String textSearch=edt_Search.getText().toString().trim();
        setTextSearch(textSearch);
    }
    private void AddTextSearchedUpApi()
    {
        for(int i=0;i<getHistorySearchList().size();i++)
        {
            if(getHistorySearchList().get(i).getTextSearch().equals(getTextSearch()))
            {
                DeleteTextSearched(getHistorySearchList().get(i).getTextSearch());
            }
        }
        ApiHistorySearch.apiHistorySearch.AddTextHistorySearchOfUser(getUid(),getTextSearch()).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });

    }
    private void DeleteTextSearched(String textSearch)
    {
        ApiHistorySearch.apiHistorySearch.DeleteProduct_list_history_searched(textSearch).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });
    }

    private void GetTextSearchedApi()
    {
        ApiHistorySearch.apiHistorySearch.GetlistHistorySearch().enqueue(new Callback<List<HistorySearch>>() {
            @Override
            public void onResponse(Call<List<HistorySearch>> call, Response<List<HistorySearch>> response) {
                List<HistorySearch>  list=new ArrayList<>();
                list=response.body();
                for(HistorySearch historySearch:list)
                {
                    if(historySearch.getUid()==getUid() )
                    {
                             historysearchlist.add(historySearch);
                             setHistorySearchList( historysearchlist);
                             adapter_history_search_of_user.setdata( historysearchlist);
                    }

                }


            }

            @Override
            public void onFailure(Call<List<HistorySearch>> call, Throwable t) {

            }
        });

    }
    private void NotificationConfirmDeleteTextSearched(String textSearched)
    {
        final Dialog dialog=new Dialog(ActivityHistorySearch.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.alert_dialog_delete_text_searched);
        Window window= dialog.getWindow();
        if(window==null)
        {
            return;
        }
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);
        dialog.setCancelable(true);
        Button btn_Confirm=dialog.findViewById(R.id.btn_Confirm_delete_text_search);
        Button btn_Cancel=dialog.findViewById(R.id.btn_cancel_delete_text_search);
        btn_Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeleteTextSearched(textSearched);
                getHistorySearchList().clear();
                GetTextSearchedApi();
                dialog.dismiss();
            }
        });
        btn_Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
    private void SetOnClick()
    {
        edt_Search.setText(getIntent().getStringExtra("KeySearch"));

            btn_search2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                           GetDataUi();
                        if (getTextSearch().length()>0) {
                            AddTextSearchedUpApi();
                            Intent intent = new Intent(ActivityHistorySearch.this, ActivityProductSearch.class);
                            intent.putExtra("KeySearch", getTextSearch());
                            intent.putExtra("Uid", getUid());
                            startActivity(intent);
                        }




                           // Intent intent = new Intent(ActivityHistorySearch.this, ActivityProductSearch.class);
                            //intent.putExtra("KeySearch", getTextSearch());
                           // intent.putExtra("Uid", getUid());
                            //startActivity(intent);


                    }


            });



        btn_Back_History_Search_Of_User.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    public String getTextSearch() {
        return TextSearch;
    }

    public void setTextSearch(String textSearch) {
        TextSearch = textSearch;
    }

    public String getTextSearched() {
        return TextSearched;
    }

    public void setTextSearched(String textSearched) {
        TextSearched = textSearched;
    }

    public int getUid() {
        return Uid;
    }
    public void setUid(int uid) {
        Uid = uid;
    }

    public List<HistorySearch> getHistorySearchList() {

        return HistorySearchList;
    }

    public void setHistorySearchList(List<HistorySearch> historySearchList) {
        HistorySearchList = historySearchList;
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        getHistorySearchList().clear();
        GetTextSearchedApi();
    }
}