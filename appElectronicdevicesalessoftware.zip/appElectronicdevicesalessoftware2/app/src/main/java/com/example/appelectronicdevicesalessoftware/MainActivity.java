package com.example.appelectronicdevicesalessoftware;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import Object.Money_user;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.telephony.mbms.MbmsErrors;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.nex3z.notificationbadge.NotificationBadge;

import java.util.ArrayList;
import java.util.List;

import Object.fragment_information_option_setup;
import Adapter.Load_fragment_view_pager_Adapter;
import Retrofit.ApiCart;
import Retrofit.ApiMoney_User;
import Utilities.Internet;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import Object.Product_add_in_cart_of_user;

public class MainActivity extends AppCompatActivity {
private ViewPager2 vp_load_fragment;
    private RecyclerView rcv_home;
    private Internet internet;
    private List<Product_add_in_cart_of_user> product_add_in_cart_of_userList;
    private NotificationBadge notificationBadge;
    private ImageButton btn_home_move_to_cart;
    private TextView tv_search1;
    private List<Money_user> money_userList;
    private List<fragment_information_option_setup> mlist;
    private LinearLayout Top_toolbar;
    private int money_account_user;
    String Username;
    int UID_Login;
private BottomNavigationView Navigation_Bottom;
private Load_fragment_view_pager_Adapter load_fragment_view_pager_adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Mapping();
        GetdataIntent();
        Initialization();
        GetMoneyAccountUser();
        //DataMoneyAcountUser();
        PerformFunction();
        SetOnClick();



    }
    private void Mapping()
    {   tv_search1=findViewById(R.id.tv_search_1);
        notificationBadge=findViewById(R.id.badge_home);
        vp_load_fragment=findViewById(R.id.view_pager_load_fragment);
        load_fragment_view_pager_adapter=new Load_fragment_view_pager_Adapter(this);
        Navigation_Bottom=findViewById(R.id.bottom_toolbar);
        btn_home_move_to_cart=findViewById(R.id.btn_home_move_cart);
        internet=new Internet();

    }
    private void GetdataIntent()
    {
        setUsername(getIntent().getStringExtra("UserName"));
        setUID_Login(getIntent().getIntExtra("UidLogin",1));
    }
    private void DataMoneyAcountUser()
    {
        Log.e("DDD",String.valueOf(getMoney_userList()));
        for(Money_user money_user:getMoney_userList())
        {
            if(money_user.getUid() == getUID_Login())
            {
                setMoney_account_user(money_user.getMoney());
            }
        }
    }
    private void GetMoneyAccountUser()
    {
        ApiMoney_User.api_money_user.Get_Money_Account_User().enqueue(new Callback<List<Money_user>>() {
            @Override
            public void onResponse(Call<List<Money_user>> call, Response<List<Money_user>> response) {

                money_userList=response.body();
                setMoney_userList(money_userList);
                for(Money_user money_user:getMoney_userList())
                {
                    if(money_user.getUid() == getUID_Login())
                    {
                        setMoney_account_user(money_user.getMoney());
                    }
                }



            }

            @Override
            public void onFailure(Call<List<Money_user>> call, Throwable t) {

            }
        });

    }
    private  void Initialization()
    {
        product_add_in_cart_of_userList=new ArrayList<Product_add_in_cart_of_user>();
        money_userList=new ArrayList<Money_user>();
    }
    private void UpdateProductCartCount()
    {
        ApiCart.apicart.GetProductInCart().enqueue(new Callback<List<Product_add_in_cart_of_user>>() {
            @Override
            public void onResponse(Call<List<Product_add_in_cart_of_user>> call, Response<List<Product_add_in_cart_of_user>> response) {
                List<Product_add_in_cart_of_user> list=new ArrayList<>();
                list=response.body();
                for(Product_add_in_cart_of_user product_add_in_cart_of_user:list)
                {
                    if(product_add_in_cart_of_user.getUid()==getUID_Login())
                    {
                        product_add_in_cart_of_userList.add(product_add_in_cart_of_user);
                        setProduct_add_in_cart_of_userList( product_add_in_cart_of_userList);
                       if(getProduct_add_in_cart_of_userList().size()>0)
                        {
                            notificationBadge.setVisibility(View.VISIBLE);
                            notificationBadge.setNumber(getProduct_add_in_cart_of_userList().size());
                       }
                        else
                       {
                           notificationBadge.setVisibility(View.GONE);
                       }



                    }
                }
            }

            @Override
            public void onFailure(Call<List<Product_add_in_cart_of_user>> call, Throwable t) {

            }
        });
    }
    private void PerformFunction()
    {
        vp_load_fragment.setAdapter(load_fragment_view_pager_adapter);
    }
    private void SetOnClick()
    {
        btn_home_move_to_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,ActivityCart.class);
                intent.putExtra("Uid",getUID_Login());
                startActivity(intent);
            }
        });
        Navigation_Bottom.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id=item.getItemId();
                if(id ==R.id.btn_home)
                {
                    vp_load_fragment.setCurrentItem(0);
                }
                else if(id==R.id.btn_Endow)
                {
                    vp_load_fragment.setCurrentItem(1);
                }
                else if(id==R.id.btn_history_transaction)
                {
                    vp_load_fragment.setCurrentItem(2);
                }
                else if(id ==R.id.btn_Notification)
                {
                    vp_load_fragment.setCurrentItem(3);
                }
                else if(id ==R.id.btn_Information)
                {
                    vp_load_fragment.setCurrentItem(4);

                }
                return true;
            }
        });
        vp_load_fragment.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                switch (position)
                {
                    case 0:
                        Navigation_Bottom.getMenu().findItem(R.id.btn_home).setChecked(true);
                        break;
                    case 1:
                        Navigation_Bottom.getMenu().findItem(R.id.btn_Endow).setChecked(true);
                        break;
                    case 2:
                        Navigation_Bottom.getMenu().findItem(R.id.btn_history_transaction).setChecked(true);
                        break;
                    case 3:
                        Navigation_Bottom.getMenu().findItem(R.id.btn_Notification).setChecked(true);
                        break;
                    case 4:
                        Navigation_Bottom.getMenu().findItem(R.id.btn_Information).setChecked(true);
                        break;

                }
            }


        });
        tv_search1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,ActivityHistorySearch.class);
                intent.putExtra("Uid",getUID_Login());
                startActivity(intent);

            }
        });

    }

    public int getMoney_account_user() {
        return money_account_user;
    }

    public void setMoney_account_user(int money_account_user) {
        this.money_account_user = money_account_user;
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter=new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(internet,intentFilter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(internet);
    }

    @Override
    public void onBackPressed() {
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public int getUID_Login() {
        return UID_Login;
    }

    public void setUID_Login(int UID_Login) {
        this.UID_Login = UID_Login;
    }

    public List<Product_add_in_cart_of_user> getProduct_add_in_cart_of_userList() {
        return product_add_in_cart_of_userList;
    }
    public void setProduct_add_in_cart_of_userList(List<Product_add_in_cart_of_user> product_add_in_cart_of_userList) {
        this.product_add_in_cart_of_userList = product_add_in_cart_of_userList;
    }

    public List<Money_user> getMoney_userList() {
        return money_userList;
    }

    public void setMoney_userList(List<Money_user> money_userList) {
        this.money_userList = money_userList;
    }

    @Override
    protected void onResume() {
        super.onResume();
        getProduct_add_in_cart_of_userList().clear();
        UpdateProductCartCount();
        GetMoneyAccountUser();
        //DataMoneyAcountUser();
    }

}
