package com.example.appelectronicdevicesalessoftware;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.mbms.MbmsErrors;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.internal.service.Common;
import com.nex3z.notificationbadge.NotificationBadge;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import Object.Product_add_in_cart_of_user;

import Object.Product;

import Fragment.Fragment_Product_Detail;
import Retrofit.ApiCart;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivityProductDetail extends AppCompatActivity {
    private String Name_Product;
    private NotificationBadge notificationBadge;
    private int Price_Product;
    private int Discount;
    private int Amount;
    private int Uid;
    private int Money_User;
    private String Img_Product;
    private List<Product_add_in_cart_of_user> product_add_in_cart_of_userList;
    private ImageButton btn_Product_detail_move_to_cart,btn_Add_Product_in_cart;
    private TextView tv_Search_Product_detail;
    private ImageButton btn_Back_Product_detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        replaceFragment(new Fragment_Product_Detail());
        GetDataFragmentHome();
        Mapping();
        Initialization();
        SetOnclick();


    }
    private void replaceFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.Content_Product_Detail, fragment);
        transaction.commit();
    }
    private void Initialization()
    {
        product_add_in_cart_of_userList=new ArrayList<>();
    }
    private void UpdateNumberProductCartCount()
    {
        ApiCart.apicart.GetProductInCart().enqueue(new Callback<List<Product_add_in_cart_of_user>>() {

            @Override
            public void onResponse(Call<List<Product_add_in_cart_of_user>> call, Response<List<Product_add_in_cart_of_user>> response) {
                List<Product_add_in_cart_of_user> list=new ArrayList<>();
                list=response.body();
                for(Product_add_in_cart_of_user product_add_in_cart_of_use:list)
                {
                    if(product_add_in_cart_of_use.getUid()==getUid())
                    {
                        product_add_in_cart_of_userList.add(product_add_in_cart_of_use);
                        setProduct_add_in_cart_of_userList(product_add_in_cart_of_userList);
                       if(getProduct_add_in_cart_of_userList().size() > 0)
                       {
                           notificationBadge.setVisibility(View.VISIBLE);
                           notificationBadge.setNumber(getProduct_add_in_cart_of_userList().size());
                       }
                       else
                       {
                           notificationBadge.setVisibility(View.GONE);
                       }

                    }
                    }
                }


            @Override
            public void onFailure(Call<List<Product_add_in_cart_of_user>> call, Throwable t) {

            }
        });

    }
    private void GetDataFragmentHome()
    {
        Product product=(Product) getIntent().getSerializableExtra("Product");
        setName_Product(product.getName_Product());
        setImg_Product(product.getImg_Product());
        setPrice_Product(product.getPrice_Product());
        setAmount(product.getAmount());
        setDiscount(product.getDiscount());
        int uid=getIntent().getIntExtra("Uid",1);
        setUid(uid);

    }
    private void Mapping()
    {
        notificationBadge=findViewById(R.id.badge);
        btn_Add_Product_in_cart=findViewById(R.id.btn_add_product_in_cart);
        btn_Back_Product_detail=findViewById(R.id.btn_back_product_detail);
        tv_Search_Product_detail=findViewById(R.id.tv_search_product_detail);
        btn_Product_detail_move_to_cart=findViewById(R.id.btn_product_detail_move_cart);
    }

    public int getMoney_User() {
        return Money_User;
    }

    public void setMoney_User(int money_User) {
        Money_User = money_User;
    }

    private void SetOnclick()
    {
        btn_Add_Product_in_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 AddProductInCart();
                 getProduct_add_in_cart_of_userList().clear();
                 UpdateNumberProductCartCount();
            }
        });
        btn_Product_detail_move_to_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ActivityProductDetail.this,ActivityCart.class);
                intent.putExtra("Uid",getUid());
                startActivity(intent);
            }
        });
        btn_Back_Product_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        tv_Search_Product_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ActivityProductDetail.this,ActivityHistorySearch.class);
                startActivity(intent);
            }
        });
    }
    private void AddProductInCart()
    {
        int s=0,p=0;
        s=getDiscount() * (getPrice_Product()/100);
        p=getPrice_Product()-s;
        //Log.e("AAA",String.valueOf(s));
        Log.e("BBB",String.valueOf(p));
        ApiCart.apicart.AddproductInCartofUser(getUid(),getName_Product(),p,getImg_Product()).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Toast.makeText(ActivityProductDetail.this,"Đã thêm thanhg công",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(ActivityProductDetail.this,"Failed",Toast.LENGTH_SHORT).show();

            }
        });
    }

    public String getName_Product() {
        return Name_Product;
    }

    public void setName_Product(String name_Product) {
        Name_Product = name_Product;
    }

    public int getPrice_Product() {
        return Price_Product;
    }

    public void setPrice_Product(int price_Product) {
        Price_Product = price_Product;
    }

    public int getDiscount() {
        return Discount;
    }

    public void setDiscount(int discount) {
        Discount = discount;
    }

    public int getAmount() {
        return Amount;
    }

    public void setAmount(int amount) {
        Amount = amount;
    }

    public String getImg_Product() {
        return Img_Product;
    }

    public void setImg_Product(String img_Product) {
        Img_Product = img_Product;
    }

    public int getUid() {
        return Uid;
    }

    public void setUid(int uid) {
        Uid = uid;
    }

    public List<Product_add_in_cart_of_user> getProduct_add_in_cart_of_userList() {
        return product_add_in_cart_of_userList;
    }

    public void setProduct_add_in_cart_of_userList(List<Product_add_in_cart_of_user> product_add_in_cart_of_userList) {
        this.product_add_in_cart_of_userList = product_add_in_cart_of_userList;
    }

    @Override
    protected void onResume() {
        super.onResume();
        getProduct_add_in_cart_of_userList().clear();
        UpdateNumberProductCartCount();
    }
}