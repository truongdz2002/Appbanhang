package com.example.appelectronicdevicesalessoftware;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import DatabaseUserOffline.DataBaseUserOffline;
import Login.ActivityLogin;
import Object.SaveAccountUserOffline;
import Object.User;
import Retrofit.ApiUser;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashActivity extends AppCompatActivity {
    private List<SaveAccountUserOffline> listUsersOffline;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                NextActivity();

            }
        }, 3000);
    }

    private void NextActivity() {
        listUsersOffline = new ArrayList<>();
        listUsersOffline = DataBaseUserOffline.getInstance(SplashActivity.this).userOffline().GetListSavePhone();
        if (listUsersOffline.size() == 0) {
            Intent intent = new Intent(SplashActivity.this, ActivityLogin.class);
            startActivity(intent);
            finish();
        } else {
            GetDataUserDatabase();

        }


    }
    private void GetDataUserDatabase()
    {

        ApiUser.apiUser.GetAccountUsers().enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                for (SaveAccountUserOffline saveAccountUserOffline : listUsersOffline) {
                    Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                    intent.putExtra("UidLogin", saveAccountUserOffline.getUid());
                    intent.putExtra("UserName",saveAccountUserOffline.getUserName());
                    Toast.makeText(SplashActivity.this, "Đăng nhập thành công", Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                    finishAffinity();
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Toast.makeText(SplashActivity.this, "Lỗi sever đang sửa chữa", Toast.LENGTH_SHORT).show();

            }
        });
    }


}

